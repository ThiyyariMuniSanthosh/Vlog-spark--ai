import "./globals.css";

export const metadata = {
  title: "VlogSpark AI — Creator Video Studio",
  description: "Turn a topic into a short-form AI video with your own narration.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
