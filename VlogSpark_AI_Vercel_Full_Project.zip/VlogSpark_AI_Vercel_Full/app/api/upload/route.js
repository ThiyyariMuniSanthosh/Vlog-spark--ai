import { handleUpload } from "@vercel/blob/client";
import { NextResponse } from "next/server";

export const runtime = "nodejs";

export async function POST(request) {
  try {
    const body = await request.json();
    const jsonResponse = await handleUpload({
      body,
      request,
      onBeforeGenerateToken: async (pathname) => ({
        allowedContentTypes: ["audio/mpeg", "audio/mp3", "audio/wav", "audio/x-wav", "audio/mp4", "audio/aac", "audio/ogg", "audio/webm", "audio/x-m4a"],
        addRandomSuffix: true,
        tokenPayload: JSON.stringify({ purpose: "vlogspark-user-narration" }),
      }),
      onUploadCompleted: async ({ blob }) => {
        console.log("Narration uploaded:", blob.pathname);
      },
    });
    return NextResponse.json(jsonResponse);
  } catch (error) {
    console.error("blob upload route:", error);
    return NextResponse.json({ error: error.message || "Upload token could not be created." }, { status: 400 });
  }
}
