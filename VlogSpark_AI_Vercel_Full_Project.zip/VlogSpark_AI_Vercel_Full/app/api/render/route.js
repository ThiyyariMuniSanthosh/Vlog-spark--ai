import { NextResponse } from "next/server";
import { requireEnv } from "@/lib/providers";

export const runtime = "nodejs";
export const maxDuration = 30;

export async function POST(request) {
  try {
    const { videoUrls, voiceUrl, duration, title } = await request.json();
    if (!Array.isArray(videoUrls) || videoUrls.length !== 6 || videoUrls.some((u) => typeof u !== "string" || !u.startsWith("https://"))) {
      return NextResponse.json({ error: "Six valid generated video URLs are required." }, { status: 400 });
    }
    if (!voiceUrl || !voiceUrl.startsWith("https://")) {
      return NextResponse.json({ error: "A hosted voice recording URL is required." }, { status: 400 });
    }
    if (![30, 48, 60].includes(Number(duration))) {
      return NextResponse.json({ error: "Invalid duration." }, { status: 400 });
    }
    const key = requireEnv("SHOTSTACK_API_KEY");
    const stage = process.env.SHOTSTACK_ENV === "v1" ? "v1" : "stage";
    const clipLength = Number(duration) / 6;
    const videoClips = videoUrls.map((src, index) => ({
      asset: { type: "video", src, volume: 0 },
      start: index * clipLength,
      length: clipLength,
      fit: "cover",
      transition: { in: index === 0 ? "fade" : "none", out: index === 5 ? "fade" : "none" },
    }));
    const audioClip = {
      asset: { type: "audio", src: voiceUrl },
      start: 0,
      length: Number(duration),
      volume: 1,
    };
    const edit = {
      timeline: {
        background: "#000000",
        tracks: [
          { clips: videoClips },
          { clips: [audioClip] },
        ],
      },
      output: {
        format: "mp4",
        resolution: "hd",
        aspectRatio: "9:16",
        fps: 30,
        quality: "medium",
        mute: false,
      },
    };
    const response = await fetch(`https://api.shotstack.io/edit/${stage}/render`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-api-key": key, Accept: "application/json" },
      body: JSON.stringify(edit),
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.message || data.error || JSON.stringify(data));
    const renderId = data.response?.id || data.data?.id;
    if (!renderId) throw new Error("Shotstack did not return a render ID.");
    return NextResponse.json({ renderId, stage, title: title || "VlogSpark video" });
  } catch (error) {
    console.error("render route:", error);
    return NextResponse.json({ error: error.message || "Could not start final render." }, { status: 500 });
  }
}
