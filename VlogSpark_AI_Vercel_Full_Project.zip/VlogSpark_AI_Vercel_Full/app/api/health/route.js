import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    ok: true,
    providers: {
      gemini: Boolean(process.env.GEMINI_API_KEY),
      fal: Boolean(process.env.FAL_KEY),
      shotstack: Boolean(process.env.SHOTSTACK_API_KEY),
      blob: Boolean(process.env.BLOB_READ_WRITE_TOKEN),
    },
  });
}
