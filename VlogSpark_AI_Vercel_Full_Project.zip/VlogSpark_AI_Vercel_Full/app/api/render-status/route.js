import { NextResponse } from "next/server";
import { requireEnv } from "@/lib/providers";

export const runtime = "nodejs";
export const maxDuration = 15;

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");
    if (!id || !/^[a-zA-Z0-9-]{10,80}$/.test(id)) {
      return NextResponse.json({ error: "Valid render ID is required." }, { status: 400 });
    }
    const key = requireEnv("SHOTSTACK_API_KEY");
    const stage = process.env.SHOTSTACK_ENV === "v1" ? "v1" : "stage";
    const response = await fetch(`https://api.shotstack.io/edit/${stage}/render/${id}`, {
      headers: { "x-api-key": key, Accept: "application/json" },
      cache: "no-store",
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.message || "Could not fetch render status.");
    const result = data.response || data.data || {};
    return NextResponse.json({
      status: result.status || "queued",
      url: result.url || null,
      error: result.error || null,
    });
  } catch (error) {
    console.error("render-status route:", error);
    return NextResponse.json({ error: error.message || "Could not check final render." }, { status: 500 });
  }
}
