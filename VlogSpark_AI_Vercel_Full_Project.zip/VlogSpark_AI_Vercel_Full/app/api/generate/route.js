import { NextResponse } from "next/server";
import { createVideoPlan, configureFal, requireEnv, VIDEO_MODEL } from "@/lib/providers";
import { fal } from "@fal-ai/client";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(request) {
  try {
    const input = await request.json();
    if (!input.topic || typeof input.topic !== "string" || input.topic.length > 300) {
      return NextResponse.json({ error: "Enter a topic up to 300 characters." }, { status: 400 });
    }
    const duration = Number(input.duration);
    if (![30, 48, 60].includes(duration)) {
      return NextResponse.json({ error: "Choose 30, 48 or 60 seconds." }, { status: 400 });
    }
    requireEnv("GEMINI_API_KEY");
    configureFal();

    const plan = await createVideoPlan({ ...input, duration });
    const clipSeconds = String(duration / 6);
    const requests = await Promise.all(plan.scenes.map(async (scene, index) => {
      const prompt = `${scene.prompt}. Vertical 9:16 social video. ${scene.scene_type === "presenter" ? "Fictional presenter footage, natural facial expression and hand gestures, speaking silently to camera; no lip-sync audio." : "Cinematic B-roll footage with a smooth camera movement."}`;
      const submitted = await fal.queue.submit(VIDEO_MODEL, {
        input: {
          prompt,
          duration: clipSeconds,
          aspect_ratio: "9:16",
          generate_audio: false,
          enable_safety_checker: true,
          negative_prompt: "subtitles, captions, text, logos, watermark, blurry, distorted anatomy, low quality",
        },
      });
      return { index, requestId: submitted.request_id, sceneType: scene.scene_type };
    }));
    return NextResponse.json({
      title: plan.title || input.topic,
      hook: plan.hook || "",
      script: plan.script,
      caption: plan.caption || "",
      hashtags: plan.hashtags || [],
      scenes: plan.scenes.map(({ scene_type, narration_line }) => ({ scene_type, narration_line })),
      requests,
    });
  } catch (error) {
    console.error("generate route:", error);
    return NextResponse.json({ error: error.message || "Could not start generation." }, { status: 500 });
  }
}
