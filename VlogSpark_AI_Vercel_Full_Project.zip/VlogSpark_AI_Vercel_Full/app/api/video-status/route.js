import { NextResponse } from "next/server";
import { fal } from "@fal-ai/client";
import { configureFal, VIDEO_MODEL } from "@/lib/providers";

export const runtime = "nodejs";
export const maxDuration = 30;

export async function POST(request) {
  try {
    const { requests } = await request.json();
    if (!Array.isArray(requests) || requests.length !== 6) {
      return NextResponse.json({ error: "Expected six video request IDs." }, { status: 400 });
    }
    configureFal();
    const items = await Promise.all(requests.map(async (item) => {
      try {
        const status = await fal.queue.status(VIDEO_MODEL, { requestId: item.requestId });
        if (status.status === "COMPLETED") {
          const result = await fal.queue.result(VIDEO_MODEL, { requestId: item.requestId });
          const videoUrl = result.data?.video?.url || result.video?.url;
          return { requestId: item.requestId, status: "COMPLETED", videoUrl };
        }
        if (status.status === "FAILED") {
          return { requestId: item.requestId, status: "FAILED", error: "Video provider could not generate this scene." };
        }
        return { requestId: item.requestId, status: status.status || "IN_QUEUE" };
      } catch (error) {
        return { requestId: item.requestId, status: "FAILED", error: error.message };
      }
    }));
    const missing = items.find((x) => x.status === "COMPLETED" && !x.videoUrl);
    if (missing) return NextResponse.json({ error: "Completed scene did not include a video URL." }, { status: 502 });
    return NextResponse.json({ items });
  } catch (error) {
    console.error("video-status route:", error);
    return NextResponse.json({ error: error.message || "Could not check video jobs." }, { status: 500 });
  }
}
