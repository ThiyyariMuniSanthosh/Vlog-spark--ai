 "use client";

import { useState } from "react";
import { upload } from "@vercel/blob/client";

const MODEL_LABEL = "Kling 3.0 Standard";

function makeSrt(script, seconds) {
  const parts = (script || "").split(/(?<=[.!?।])\s+/).filter(Boolean);
  const words = parts.map((p) => Math.max(1, p.split(/\s+/).length));
  const total = words.reduce((a, b) => a + b, 0) || 1;
  let cursor = 0;
  const stamp = (n) => {
    const ms = Math.round(n * 1000);
    const h = String(Math.floor(ms / 3600000)).padStart(2, "0");
    const m = String(Math.floor((ms % 3600000) / 60000)).padStart(2, "0");
    const s = String(Math.floor((ms % 60000) / 1000)).padStart(2, "0");
    const x = String(ms % 1000).padStart(3, "0");
    return `${h}:${m}:${s},${x}`;
  };
  return parts.map((p, i) => {
    const start = cursor;
    cursor += seconds * words[i] / total;
    return `${i + 1}\n${stamp(start)} --> ${stamp(cursor)}\n${p}\n`;
  }).join("\n");
}

export default function Home() {
  const [topic, setTopic] = useState("");
  const [language, setLanguage] = useState("English");
  const [duration, setDuration] = useState("30");
  const [platform, setPlatform] = useState("YouTube Shorts");
  const [tone, setTone] = useState("Natural and conversational");
  const [audience, setAudience] = useState("General audience");
  const [details, setDetails] = useState("");
  const [presenter, setPresenter] = useState("Fictional realistic presenter");
  const [voice, setVoice] = useState(null);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState("Ready. Add a topic and your own voice recording.");
  const [progress, setProgress] = useState(0);
  const [videoUrl, setVideoUrl] = useState("");
  const [script, setScript] = useState("");
  const [jobError, setJobError] = useState("");

  async function api(path, body) {
    const r = await fetch(path, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || data.message || "Request failed");
    return data;
  }

  async function waitForClips(requests) {
    const maxLoops = 180;
    for (let i = 0; i < maxLoops; i++) {
      const state = await api("/api/video-status", { requests });
      const done = state.items.filter((x) => x.status === "COMPLETED").length;
      const failed = state.items.find((x) => x.status === "FAILED");
      setProgress(12 + Math.round((done / requests.length) * 62));
      setStatus(`Generating video scenes: ${done}/${requests.length} completed. This can take several minutes.`);
      if (failed) throw new Error(failed.error || "A video scene failed.");
      if (done === requests.length) return state.items.map((x) => x.videoUrl);
      await new Promise((resolve) => setTimeout(resolve, 6000));
    }
    throw new Error("Video generation is taking longer than expected. Try again later; check provider job status.");
  }

  async function waitForRender(renderId, voiceUrl) {
    for (let i = 0; i < 120; i++) {
      const r = await fetch(`/api/render-status?id=${encodeURIComponent(renderId)}&voiceUrl=${encodeURIComponent(voiceUrl)}`);
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || "Could not check render.");
      if (data.status === "done") return data.url;
      if (data.status === "failed") throw new Error(data.error || "Final video render failed.");
      setProgress(80 + Math.min(18, i / 6));
      setStatus("Combining scenes, adding your voice and exporting MP4…");
      await new Promise((resolve) => setTimeout(resolve, 5000));
    }
    throw new Error("Final render is still processing. Refresh later and check the Shotstack render dashboard.");
  }

  async function generate() {
    if (!topic.trim()) return setStatus("Enter a video topic first.");
    if (!voice) return setStatus("Upload your own voice recording first.");
    if (!voice.type.startsWith("audio/")) return setStatus("Please choose an audio recording.");
    if (voice.size > 100 * 1024 * 1024) return setStatus("Audio file must be smaller than 100 MB.");
    setBusy(true); setVideoUrl(""); setJobError(""); setProgress(3);
    try {
      setStatus("Uploading your narration securely to Vercel Blob…");
      const blob = await upload(`narration/${Date.now()}-${voice.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`, voice, {
        access: "public",
        handleUploadUrl: "/api/upload",
        contentType: voice.type,
        multipart: voice.size > 5 * 1024 * 1024,
      });
      setProgress(8);
      setStatus("Writing your natural creator-style script and preparing six video scenes…");
      const plan = await api("/api/generate", {
        topic, language, duration: Number(duration), platform, tone, audience, details, presenter,
      });
      setScript(plan.script || "");
      setProgress(12);
      const urls = await waitForClips(plan.requests);
      setProgress(78);
      setStatus("Submitting finished scenes and your voice to the video editor…");
      const render = await api("/api/render", {
        videoUrls: urls, voiceUrl: blob.url, duration: Number(duration), title: plan.title,
      });
      const finalUrl = await waitForRender(render.renderId, blob.url);
      setVideoUrl(finalUrl);
      setProgress(100);
      setStatus("Your video is ready. Preview it and download the MP4.");
    } catch (e) {
      setJobError(e.message);
      setStatus(`Generation stopped: ${e.message}`);
    } finally {
      setBusy(false);
    }
  }

  function downloadSrt() {
    const content = makeSrt(script, Number(duration));
    const url = URL.createObjectURL(new Blob([content], { type: "text/plain;charset=utf-8" }));
    const a = document.createElement("a"); a.href = url; a.download = "vlogspark-subtitles.srt"; a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <main className="shell">
      <header className="top"><div className="brand">VLOG<span>SPARK</span> AI</div><div className="tag">CREATOR VIDEO STUDIO</div></header>
      <section className="hero">
        <div className="eyebrow">Your idea → AI video → MP4</div>
        <h1>Make creator-style videos from a simple idea.</h1>
        <p>Generate presenter-style and cinematic scenes, narrate with your own recording, and render a vertical video for Shorts and Reels.</p>
      </section>
      <div className="grid">
        <section className="panel">
          <h2>Build your video</h2><p className="sub">Six generated scenes • 9:16 vertical • Your own narration</p>
          <label>Video title or idea</label>
          <input className="field" value={topic} onChange={(e)=>setTopic(e.target.value)} placeholder="Example: 5 lessons I learned in college"/>
          <div className="two">
            <div><label>Language</label><select className="field" value={language} onChange={(e)=>setLanguage(e.target.value)}>{["English","Telugu","Tamil","Hindi","Kannada","Malayalam","Hinglish"].map(x=><option key={x}>{x}</option>)}</select></div>
            <div><label>Duration</label><select className="field" value={duration} onChange={(e)=>setDuration(e.target.value)}><option value="30">30 seconds</option><option value="48">48 seconds</option><option value="60">60 seconds</option></select></div>
          </div>
          <div className="two">
            <div><label>Platform</label><select className="field" value={platform} onChange={(e)=>setPlatform(e.target.value)}>{["YouTube Shorts","Instagram Reels","Facebook Reels","All vertical platforms"].map(x=><option key={x}>{x}</option>)}</select></div>
            <div><label>Speaking style</label><select className="field" value={tone} onChange={(e)=>setTone(e.target.value)}>{["Natural and conversational","Energetic creator","Educational and clear","Storytelling"].map(x=><option key={x}>{x}</option>)}</select></div>
          </div>
          <label>Audience</label><input className="field" value={audience} onChange={(e)=>setAudience(e.target.value)} placeholder="College students, beginners…"/>
          <label>Extra details (optional)</label><textarea className="field" value={details} onChange={(e)=>setDetails(e.target.value)} placeholder="Points to include, examples, ending call-to-action…"/>
          <label>Your voice recording</label>
          <div className="filebox"><input type="file" accept="audio/*" onChange={(e)=>setVoice(e.target.files?.[0] || null)}/><div className="hint">{voice ? `${voice.name} • ${(voice.size/1024/1024).toFixed(1)} MB` : "Choose an audio recording you made. MP3, WAV, M4A or AAC."}</div></div>
          <label>Presenter visual style</label><select className="field" value={presenter} onChange={(e)=>setPresenter(e.target.value)}>{["Fictional realistic presenter","Stylized animated presenter","Documentary host"].map(x=><option key={x}>{x}</option>)}</select>
          <div className="notice">Your voice recording is added as narration. Generated presenter scenes are visual footage; this version does not synchronize the presenter's lips to your recording or clone your voice.</div>
          <button className="btn" disabled={busy} onClick={generate}>{busy ? "Generating your video…" : "Generate actual AI video"}</button>
          <div className="status" aria-live="polite">{status}<div className="progress"><i style={{width:`${progress}%`}}/></div></div>
        </section>
        <section className="panel">
          <h2>Your finished video</h2><p className="sub">Preview the final render and save your files.</p>
          <div className="videoFrame">{videoUrl ? <video src={videoUrl} controls playsInline/> : <div className="empty"><div style={{fontSize:34}}>▶</div><strong>Your MP4 will appear here</strong><span>Start by entering a topic and uploading your voice.</span></div>}</div>
          {videoUrl && <div className="outputLinks"><a href={videoUrl} target="_blank" rel="noreferrer">Open MP4</a><a href={videoUrl} download="vlogspark-video.mp4">Download MP4</a><a href="#" onClick={(e)=>{e.preventDefault();downloadSrt();}}>Download estimated SRT</a></div>}
          {script && <><h3 style={{fontFamily:"Space Grotesk",fontSize:16,marginTop:22}}>Generated script</h3><div className="scriptBox">{script}</div></>}
          <div className="notice"><b>External services:</b> Gemini writes the script, fal.ai Kling generates video scenes, Vercel Blob stores the uploaded narration temporarily, and Shotstack assembles the final MP4. Provider usage can cost money. Begin with Shotstack's sandbox setting.</div>
          <p className="footer">Use only recordings you have permission to upload. The voice file is stored in a public Vercel Blob URL so the render provider can access it; this starter project does not automatically delete it. Delete it from your Blob store after rendering if you no longer need it. Add authentication, rate limits and privacy controls before opening the site to the public.</p>
        </section>
      </div>
      <p className="footer">VlogSpark AI • Next.js + Vercel Functions • Generated media may contain model errors; review before publishing.</p>
    </main>
  );
}
